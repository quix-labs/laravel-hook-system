<?php

use QuixLabs\LaravelHookSystem\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
